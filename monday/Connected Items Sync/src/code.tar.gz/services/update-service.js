const initMondayClient = require('monday-sdk-js');

const getConnectedColumnsAndItems = async (token, boardId, itemId) => {
    try {
      const mondayClient = initMondayClient();
      mondayClient.setToken(token);
      mondayClient.setApiVersion('2025-01');
  
      // Step 1: Get all connected columns for the board
      const columnsQuery = `query($boardId: ID!) {
        boards(ids: [$boardId]) {
          columns {
            id
            title
            type
          }
        }
      }`;
  
      const columnsResponse = await mondayClient.api(columnsQuery, { variables: { boardId } });
      const connectedColumns = columnsResponse.data.boards[0].columns.filter(
        (column) => column.type === "board-relation"
      );
  
      if (connectedColumns.length === 0) {
        console.log("No connected columns found.");
        return [];
      }
      // Step 2: Fetch the values in connected columns for the specified item
      const columnIds = connectedColumns.map((col) => col.id);

      const connectedItemsQuery = `query($itemId: [ID!], $columnIds: [String!]) {
        items(ids: $itemId) {
          column_values(ids: $columnIds) {
            id
            value
          }
        }
      }`;
  
      const connectedItemsResponse = await mondayClient.api(connectedItemsQuery, {
        variables: { itemId, columnIds },
      });
  
      const columnValues = connectedItemsResponse.data.items[0].column_values;
  
      // Step 3: Extract and return the IDs of connected items
      const connectedItemIds = [];
      columnValues.forEach((column) => {
        if (column.value) {
          const parsedValue = JSON.parse(column.value);
          if (parsedValue.linkedPulseIds) {
            parsedValue.linkedPulseIds.forEach((pulse) => {
              connectedItemIds.push(pulse.linkedPulseId);
            });
          }
        }
      });
      return connectedItemIds;
    } catch (err) {
      console.error("Error:", err);
      return [];
    }
  };

const updateConnectedItems = async (token, itemId, value) => {
  try {
    const mondayClient = initMondayClient({ token });
    mondayClient.setApiVersion("2025-01");

    
    const query = `mutation ($itemId: ID!, $value: String!) {
        create_update(itemId: $itemId, value: $value) {
            id
        }
    }`;
    const variables = { itemId, value };
    const response = await mondayClient.api(query, { variables });
    return response;
  } catch (err) {
    console.error(err);
  }
};

module.exports = {
  getConnectedColumnsAndItems,
  updateConnectedItems,
};
