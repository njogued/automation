const mondayService = require('../services/monday-service');
const updateService = require('../services/update-service');
const transformationService = require('../services/transformation-service');
const { TRANSFORMATION_TYPES } = require('../constants/transformation');

async function executeAction(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;

  try {
    const { inputFields } = payload;
    const { boardId, itemId, sourceColumnId, targetColumnId, transformationType } = inputFields;

    const text = await mondayService.getColumnValue(shortLivedToken, itemId, sourceColumnId);
    if (!text) {
      return res.status(200).send({});
    }
    const transformedText = transformationService.transformText(
      text,
      transformationType ? transformationType.value : 'TO_UPPER_CASE'
    );

    await mondayService.changeColumnValue(shortLivedToken, boardId, itemId, targetColumnId, transformedText);

    return res.status(200).send({});
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}

async function getRemoteListOptions(req, res) {
  try {
    return res.status(200).send(TRANSFORMATION_TYPES);
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}

async function updateConnectedItems(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;

  try {
    const { inputFields } = payload;
    const { boardId, itemId, update } = inputFields;

    console.log('update', update);
    console.log('boardId', boardId);
    console.log('itemId', itemId);

    // Step 1: Get all connected items
    const connectedItemIds = await updateService.getConnectedColumnsAndItems(shortLivedToken, boardId, itemId);

    if (connectedItemIds.length === 0) {
      return res.status(404).send({ message: "No connected items found for the specified item." });
    }

    // Step 2: Update each connected item with the provided value
    const updateResults = [];
    for (const connectedItemId of connectedItemIds) {
      const updateResult = await updateService.updateConnectedItems(shortLivedToken, connectedItemId, update);
      updateResults.push(updateResult);
    }

    // Step 3: Return the update results
    return res.status(200).send({
      message: "Connected items updated successfully.",
      updatedItems: updateResults.map((result) => result.data.create_update.id),
    });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: "Internal server error" });
  }
}


module.exports = {
  executeAction,
  getRemoteListOptions,
  updateConnectedItems,
};
